#ifndef CLEANROOM_RUNTIME_E2E_H
#define CLEANROOM_RUNTIME_E2E_H

#include <stdint.h>
#include <stdbool.h>
#include "runtime.h"
#include "orchestrator.h"
#include "token_ledger.h"
#include "crypto_key_schedule.h"
#include "rtsp_server_loop.h"
#include "ssdp_server_loop.h"

typedef struct {
    cleanroom_runtime_t rt;
    orch_task_t tasks[8];
    token_ledger_t ledger;
    ctr_key_schedule_t ks;
    int rtsp_fd;
    int ssdp_fd;
} cleanroom_runtime_e2e_t;

int cleanroom_runtime_e2e_init(cleanroom_runtime_e2e_t *e);
void cleanroom_runtime_e2e_deinit(cleanroom_runtime_e2e_t *e);
int cleanroom_runtime_e2e_start(cleanroom_runtime_e2e_t *e);
int cleanroom_runtime_e2e_stop(cleanroom_runtime_e2e_t *e);

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif /* CLEANROOM_RUNTIME_E2E_H */
